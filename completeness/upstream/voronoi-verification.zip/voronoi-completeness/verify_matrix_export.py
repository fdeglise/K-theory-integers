"""Check source fidelity and every newly exported matrix identity exactly.

This complements verify_completeness.py, which checks the enumeration and
shortest-vector certificates. Neither program is a Lean formalization.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import csv, gzip, hashlib, json, time
from export_all_matrices import sources
from matrix_examples import identity, transpose, multiply, determinant, rank, tensor_rows
from noncyclic import code_generated
from verify_completeness import verify_result

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'matrices'


def matrix(A):
    return [[F(x) for x in row] for row in A]


def main():
    start = time.monotonic()
    document = json.loads((OUT/'all_matrices.json').read_text())
    records = document['records']
    index = {r['id']: r for r in records}
    original = {item[0]: item for item in sources()}
    assert len(index) == len(records) == len(original) == 966
    assert set(index) == set(original)
    for name, expected in document['source_sha256'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == expected
    counts = Counter()
    for ident, item in original.items():
        _, name, key, n, phase, mod, gens, extra, result = item
        rec = index[ident]
        assert (rec['source_file'], rec['source_entry'], rec['rank'], rec['phase'],
                rec['lattice_modulus'], rec['lattice_generator_rows'], rec['status']) == (
                name, key, n, phase, mod, gens, result['status'])
        S = identity(n)
        if extra is not None:
            assert list(map(F, rec['extra_vector'])) == list(map(F, extra))
            S.append(list(map(F, extra)))
        else:
            assert rec['extra_vector'] is None
        code = {tuple(F(x, mod) for x in c) for c in code_generated(gens, mod)}
        assert rec['lattice_index'] == len(code)
        if result['status'] == 'accepted':
            gram, geo = rec['gram'], rec['derived_geometry']
            Q = matrix(gram['Q'])
            assert Q == matrix(result['Q'])
            assert Q == transpose(Q)
            U, ds = matrix(gram['derived_U']), list(map(F, gram['derived_D']))
            assert len(ds) == n and all(d > 0 for d in ds)
            assert all(U[i][i] == 1 and all(U[i][j] == 0 for j in range(i)) for i in range(n))
            D = [[ds[i] if i == j else F(0) for j in range(n)] for i in range(n)]
            assert multiply(multiply(transpose(U), D), U) == Q
            assert determinant(Q) == F(gram['det_Q'])
            B, Bi = matrix(geo['integral_basis_B']), matrix(geo['integral_basis_inverse'])
            assert multiply(B, Bi) == multiply(Bi, B) == identity(n)
            assert abs(determinant(B)) == F(1, len(code))
            assert all(tuple(x % 1 for x in col) in code for col in transpose(B))
            assert all(x.denominator == 1 for row in Bi for x in row)
            H = matrix(geo['gram_in_integral_basis'])
            A = matrix(geo['integer_gram_matrix'])
            scale = geo['integer_gram_scale']
            assert isinstance(scale, int) and scale > 0
            assert multiply(multiply(transpose(B), Q), B) == H
            assert A == [[scale*x for x in row] for row in H]
            assert all(x.denominator == 1 for row in A for x in row)
            SV = matrix(geo['minimal_vectors_in_integral_basis'])
            assert SV == multiply(S, transpose(Bi))
            assert all(x.denominator == 1 for row in SV for x in row)
            assert matrix(geo['minimal_vector_rows']) == S
            for v in S:
                assert multiply(multiply([v], Q), transpose([v])) == [[F(1)]]
            T = matrix(geo['tensor_matrix'])
            assert geo['tensor_column_pairs'] == [[i+1, j+1] for i in range(n) for j in range(i, n)]
            assert T == tensor_rows(S)
            assert rank(T) == geo['tensor_rank'] == len(S)
            counts['Gram_matrices_and_derived_geometry_checked'] += 1
        else:
            c = rec['certificate']
            saved = result['certificate']
            if phase == 'cyclic':
                raw = [{'row': a, 'rhs': b, 'weight': w, 'vector': v}
                       for (a, b, w), v in zip(saved['constraints'], saved['vectors'])]
                equalities = []
            else:
                raw, equalities = saved['constraints'], saved['equalities']
            assert matrix(c['A_ineq']) == matrix([s['row'] for s in raw])
            assert list(map(F, c['b_ineq'])) == [F(s['rhs']) for s in raw]
            assert list(map(F, c['lambda'])) == [F(s['weight']) for s in raw]
            assert c['inequality_vectors'] == [s['vector'] for s in raw]
            assert matrix(c['E_eq']) == matrix([s['row'] for s in equalities])
            assert list(map(F, c['h_eq'])) == [F(s['rhs']) for s in equalities]
            assert list(map(F, c['mu'])) == [F(s['weight']) for s in equalities]
            assert F(c['weighted_rhs']) == F(saved['bound'])
            verify_result(n, mod, gens, result, extra=extra, cyclic_format=(phase == 'cyclic'))
            counts['exclusion_certificates_checked'] += 1
        if 'symmetry' in rec:
            a = rec['symmetry']
            P, R = matrix(a['P_in_minimal_basis']), matrix(a['P_on_rays'])
            assert determinant(P) == determinant(R) == -1
            assert multiply(S, transpose(P)) == multiply(R, S)
            for g in gens:
                assert multiply(P, transpose([g])) == transpose([g])
            if result['status'] == 'accepted':
                Pi = matrix(a['P_in_integral_basis'])
                assert multiply(multiply(Bi, P), B) == Pi
                assert all(x.denominator == 1 for row in Pi for x in row)
                assert determinant(Pi) == -1
                assert multiply(multiply(transpose(P), Q), P) == Q
                assert multiply(multiply(transpose(Pi), A), Pi) == A
            counts['configuration_symmetries_checked'] += 1
    with (OUT/'matrix_index.csv').open(newline='') as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 966 and {r['id'] for r in rows} == set(index)
    for row in rows:
        r = index[row['id']]
        assert int(row['rank']) == r['rank'] and row['status'] == r['status']
        assert int(row['gram_rows']) == (r['rank'] if 'gram' in r else 0)
        assert int(row['certificate_inequalities']) == len(r.get('certificate', {}).get('A_ineq', []))
    with (OUT/'cell_index.csv').open(newline='') as f:
        cells = list(csv.DictReader(f))
    assert Counter(row['rank'] for row in cells) == {'8': 106, '9': 44}
    memberships = set()
    for cell in cells:
        ids = cell['all_presentation_records'].split(';')
        assert cell['representative_record'] in ids
        for ident in ids:
            assert ident not in memberships
            memberships.add(ident)
            assert index[ident]['cell_class_id'] == cell['cell_class_id']
            assert index[ident]['status'] == 'accepted'
    assert memberships == {r['id'] for r in records if 'cell_class_id' in r}
    legacy = document['rank5_boundary']
    d, U = matrix(legacy['d9']), matrix(legacy['derived_unimodular_column_change'])
    assert abs(determinant(U)) == 1
    assert multiply(d, U) == matrix(legacy['derived_Smith_form']) == [[F(1)]+[F(0)]*6]
    counts['final_cell_classes_indexed'] = len(cells)
    counts['legacy_Smith_identity_checked'] = 1
    summary = {'status': 'passed', 'checks': dict(counts),
               'seconds': round(time.monotonic()-start, 3),
               'scope': 'Exact source fidelity and exported matrix identities; run verify_completeness.py for enumeration and shortest-vector verification.'}
    (OUT/'matrix_verification_summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == '__main__':
    main()
